import java.sql.*;

public class EmployeeCRUD {
    public static void main(String[] args) throws Exception {
        // 1. Load JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        // 2. Establish Connection
        Connection conn = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/company", "root", "admin123");
        
        // 3. Create table if not exists
        Statement stmt = conn.createStatement();
        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS Employee (" +
                          "empId INT PRIMARY KEY, " +
                          "empName VARCHAR(40), " +
                          "salary DOUBLE)");
        
        // 4. INSERT using PreparedStatement
        PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Employee VALUES (?, ?, ?)");
        pstmt.setInt(1, 101);
        pstmt.setString(2, "John Doe");
        pstmt.setDouble(3, 50000);
        pstmt.executeUpdate();
        System.out.println(" Employee 101 inserted");
        
        pstmt.setInt(1, 102);
        pstmt.setString(2, "Jane Smith");
        pstmt.setDouble(3, 60000);
        pstmt.executeUpdate();
        System.out.println(" Employee 102 inserted");
        
        pstmt.setInt(1, 103);
        pstmt.setString(2, "Bob Johnson");
        pstmt.setDouble(3, 55000);
        pstmt.executeUpdate();
        System.out.println(" Employee 103 inserted");
        
        // 5. SELECT using PreparedStatement
        pstmt = conn.prepareStatement("SELECT * FROM Employee");
        ResultSet rs = pstmt.executeQuery();
        System.out.println("\n All Employees:");
        while (rs.next()) {
            System.out.println(rs.getInt(1) + " | " + rs.getString(2) + " | " + rs.getDouble(3));
        }
        rs.close();
        
        // 6. UPDATE using PreparedStatement
        pstmt = conn.prepareStatement("UPDATE Employee SET salary = ? WHERE empId = ?");
        pstmt.setDouble(1, 65000);
        pstmt.setInt(2, 102);
        int updated = pstmt.executeUpdate();
        System.out.println("\n " + updated + " employee(s) updated (empId 102 salary → 65000)");
        
        // 7. DELETE using PreparedStatement
        pstmt = conn.prepareStatement("DELETE FROM Employee WHERE empId = ?");
        pstmt.setInt(1, 103);
        int deleted = pstmt.executeUpdate();
        System.out.println(" " + deleted + " employee(s) deleted (empId 103)");
        
        // 8. SELECT again to see final records
        rs = stmt.executeQuery("SELECT * FROM Employee");
        System.out.println("\n Final Employees:");
        while (rs.next()) {
            System.out.println(rs.getInt(1) + " | " + rs.getString(2) + " | " + rs.getDouble(3));
        }
        
        // 9. Close connections
        rs.close();
        pstmt.close();
        stmt.close();
        conn.close();
        System.out.println("\n Connection closed");
    }
}