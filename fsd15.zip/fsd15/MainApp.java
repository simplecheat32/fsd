import java.util.*;
import java.util.stream.*;

public class MainApp {

    public static void main(String[] args) {

        List<Student> students = Arrays.asList(
                new Student(1, "Alice", 85),
                new Student(2, "Bob", 35),
                new Student(3, "Charlie", 60),
                new Student(4, "David", 25),
                new Student(5, "Eva", 90)
        );

        // 🔹 1. GROUPING (based on pass/fail category)
        System.out.println("=== GROUPING ===");

        Map<String, List<Student>> grouped =
                students.stream()
                        .collect(Collectors.groupingBy(
                                s -> s.getMarks() >= 40 ? "PASS" : "FAIL"
                        ));

        grouped.forEach((key, value) -> {
            System.out.println(key + ": " + value);
        });


        // 🔹 2. AVERAGE MARKS
        System.out.println("\n=== AVERAGE MARKS ===");

        double avg =
                students.stream()
                        .collect(Collectors.averagingDouble(Student::getMarks));

        System.out.println("Average Marks = " + avg);


        // 🔹 3. PARTITIONING (true/false)
        System.out.println("\n=== PARTITIONING ===");

        Map<Boolean, List<Student>> partitioned =
                students.stream()
                        .collect(Collectors.partitioningBy(
                                s -> s.getMarks() >= 40
                        ));

        System.out.println("PASS: " + partitioned.get(true));
        System.out.println("FAIL: " + partitioned.get(false));
    }
}