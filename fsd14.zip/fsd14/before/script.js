function greet() {
    console.log("Welcome to profile page");
}
greet();