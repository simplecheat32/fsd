import java.sql.*;
public class StudentCRUD {
public static void main(String[] args) {
try {
// Load JDBC Driver
Class.forName("com.mysql.cj.jdbc.Driver");
// Establish Connection
Connection con = DriverManager.getConnection(
"jdbc:mysql://localhost:3306/college", "root", "admin123");
Statement stmt = con.createStatement();
// INSERT
stmt.executeUpdate("INSERT INTO Students VALUES (1,'Amit',75)");
stmt.executeUpdate("INSERT INTO Students VALUES (2,'Neha',65)");
// SELECT
ResultSet rs = stmt.executeQuery("SELECT * FROM Students");
System.out.println("Student Records:");
while (rs.next()) {
System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getInt(3));
}
// UPDATE
stmt.executeUpdate("UPDATE Students SET marks=80 WHERE rollNo=1");
// DELETE
stmt.executeUpdate("DELETE FROM Students WHERE rollNo=2");
con.close();
}
catch (Exception e) {
e.printStackTrace();
}
}
}