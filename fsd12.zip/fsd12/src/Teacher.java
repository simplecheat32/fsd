import org.springframework.beans.factory.annotation.Autowired;

public class Teacher {

    private String name;

    @Autowired
    private Course course;

    public Teacher() {}

    public Teacher(String name) {
        this.name = name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void teach() {
        System.out.println("Teacher: " + name);
        course.display();
    }
}