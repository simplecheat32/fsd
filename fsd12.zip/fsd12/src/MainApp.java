import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

    public static void main(String[] args) {

        ApplicationContext context =
                new ClassPathXmlApplicationContext("applicationContext.xml");

        System.out.println("=== FIRST CALL ===");

        Teacher t1 = (Teacher) context.getBean("teacherBean");
        Teacher t2 = (Teacher) context.getBean("teacherBean");

        t1.teach();
        t2.teach();

        System.out.println("\nTeacher objects:");
        System.out.println(t1);
        System.out.println(t2);

        Course c1 = (Course) context.getBean("courseBean");
        Course c2 = (Course) context.getBean("courseBean");

        System.out.println("\nCourse objects:");
        System.out.println(c1);
        System.out.println(c2);
    }
}