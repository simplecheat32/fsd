<%@ page language="java" contentType="text/html; charset=UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Greeting Message</title>
</head>
<body>
    <%
        String name = request.getParameter("username");
        String city = request.getParameter("city");
        
        String greeting = "Hello " + name + "!";
        String message = "Welcome to " + city + ". Have a great day!";
    %>
    
    <h2>Your Personalized Greeting:</h2>
    
    <table border="1" cellpadding="10">
        <tr bgcolor="lightblue">
            <th>Field</th>
            <th>Details</th>
        </tr>
        <tr>
            <td>Name</td>
            <td><%= name %></td>
        </tr>
        <tr>
            <td>City</td>
            <td><%= city %></td>
        </tr>
        <tr>
            <td>Greeting</td>
            <td><%= greeting %></td>
        </tr>
        <tr>
            <td>Message</td>
            <td><%= message %></td>
        </tr>
    </table>
    
    <br>
    <a href="index.html">Go Back</a>
</body>
</html>