import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class SetCookieServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        
        String name = req.getParameter("name");
        String value = req.getParameter("value");
        
        // Create cookie
        Cookie cookie = new Cookie(name, value);
        cookie.setMaxAge(60 * 60); // 1 hour expiry
        res.addCookie(cookie);
        
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.println("<html><body>");
        out.println("<h2>Cookie Set Successfully!</h2>");
        out.println("<p>Name: " + name + "<br>Value: " + value + "</p>");
        out.println("<a href='index.html'>Back</a>");
        out.println("</body></html>");
    }
}