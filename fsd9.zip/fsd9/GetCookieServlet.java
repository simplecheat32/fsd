import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class GetCookieServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        
        Cookie[] cookies = req.getCookies();
        
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.println("<html><body>");
        out.println("<h2>Stored Cookies</h2>");
        
        if(cookies == null || cookies.length == 0) {
            out.println("<p style='color:red'>No cookies found!</p>");
        } else {
            out.println("<table border='1' cellpadding='5'>");
            out.println("<tr><th>Cookie Name</th><th>Cookie Value</th></tr>");
            for(Cookie c : cookies) {
                out.println("<tr><td>" + c.getName() + "</td>");
                out.println("<td>" + c.getValue() + "</td></tr>");
            }
            out.println("</table>");
        }
        
        out.println("<br><a href='index.html'>Back</a>");
        out.println("</body></html>");
    }
}