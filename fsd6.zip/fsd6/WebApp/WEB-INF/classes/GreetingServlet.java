import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class GreetingServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String name = request.getParameter("username");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html><body>");
        out.println("<h2>Hello " + name + "! Welcome to Servlets.</h2>");
        out.println("</body></html>");
    }
}