import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class CalculatorServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        double num1 = Double.parseDouble(request.getParameter("num1"));
        double num2 = Double.parseDouble(request.getParameter("num2"));
        String operation = request.getParameter("operation");
        
        double result = 0;
        if (operation.equals("Add")) {
            result = num1 + num2;
        } else if (operation.equals("Subtract")) {
            result = num1 - num2;
        }
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>Result: " + result + "</h2>");
        out.println("<a href='index.html'>Back</a>");
        out.println("</body></html>");
    }
}