import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class EmployeeServlet extends HttpServlet {
    
    // Sample employee data (hardcoded for simplicity)
    String[][] employees = {
        {"101", "John Smith", "Manager", "50000"},
        {"102", "Sarah Jones", "Developer", "45000"},
        {"103", "Mike Brown", "Tester", "40000"},
        {"104", "Lisa Wong", "HR", "42000"}
    };
    
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        
        String empNo = req.getParameter("empNo");
        String found = null;
        
        // Search for employee
        for(String[] emp : employees) {
            if(emp[0].equals(empNo)) {
                found = "<table border='1' cellpadding='5'>" +
                        "<tr><th>Field</th><th>Details</th></tr>" +
                        "<tr><td>Employee No</td><td>" + emp[0] + "</td></tr>" +
                        "<tr><td>Name</td><td>" + emp[1] + "</td></tr>" +
                        "<tr><td>Designation</td><td>" + emp[2] + "</td></tr>" +
                        "<tr><td>Salary</td><td>" + emp[3] + "</td></tr>" +
                        "</table>";
                break;
            }
        }
        
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.println("<html><body>");
        out.println("<h2>Employee Details</h2>");
        
        if(found != null) {
            out.println(found);
        } else {
            out.println("<p style='color:red'>Employee not found!</p>");
        }
        
        out.println("<br><a href='index.html'>Back</a>");
        out.println("</body></html>");
    }
}