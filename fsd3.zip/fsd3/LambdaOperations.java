import java.util.Scanner;
@FunctionalInterface
interface Operation {
int compute(int a, int b);
}
public class LambdaOperations {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
System.out.print("Enter first number: ");
int a = sc.nextInt();
System.out.print("Enter second number: ");
int b = sc.nextInt();
// Lambda expressions
Operation add = (x, y) -> x + y;
Operation sub = (x, y) -> x - y;
Operation mul = (x, y) -> x * y;
Operation div = (x, y) -> y != 0 ? x / y : 0;
System.out.println("Addition: " + add.compute(a, b));
System.out.println("Subtraction: " + sub.compute(a, b));
System.out.println("Multiplication: " + mul.compute(a, b));
System.out.println("Division: " + div.compute(a, b));
sc.close();
}
}